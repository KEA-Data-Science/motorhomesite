	-- 	Address insert statemtent:
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Fasanvej', '12', '2300');
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Gryntevej', '12', '2500');
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Piskerisvænget', '12', '3300');
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Næslingegade', '12', '2302');
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Nællingegade', '14', '2302');
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Næslimgegade', '16', '2302');
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Næslindegade', '18', '2302');
INSERT INTO `motorhome`.`address` (`country`, `roadName`, `houseNumber`, `postCode`) VALUES ('Danmark', 'Udlejervej', '42', '1602');

	-- 	Person insert statement:
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Albert', 'Bertino', 'albe@fakemail.com', 'CUSTOMER', '19740503', '20200501', '1');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Casper', 'Dollar', 'cado@fakemail.com', 'CUSTOMER', '19800503', '20200412', '2');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Elfin', 'Fiska', 'cado@fakemail.com', 'CUSTOMER', '19810503', '20200411', '3');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'George', 'Henriksen', 'cado@fakemail.com', 'CUSTOMER', '19820503', '20200410', '4');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Ioanna', 'Klemmensen', 'cado@fakemail.com', 'CUSTOMER', '19830503', '20200409', '5');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Mette', 'Nielsen', 'cado@fakemail.com', 'CUSTOMER', '19840503', '20200408', '6');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Petra', 'Sorønne', 'cado@fakemail.com', 'CUSTOMER', '19850503', '20200407', '7');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Peter', 'Sørensen', 'cado@fakemail.com', 'ADMIN', '19750503', '20200407', '8');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Søren', 'Petersen', 'cado@fakemail.com', 'SALES', '19950503', '20200407', '8');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'David', 'Tuska', 'cado@fakemail.com', 'SALES', '19880503', '20200407', '8');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'David', 'Desmond', 'cado@fakemail.com', 'SALES', '19650503', '20200407', '8');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Oskar', 'Ingolfa', 'cado@fakemail.com', 'OTHER', '19810503', '20200407', '8');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'David', 'Tuska', 'cado@fakemail.com', 'OTHER', '19650503', '20200407', '8');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Carina', 'Delfina', 'cado@fakemail.com', 'MECHANIC', '19450503', '20200407', '8');
INSERT INTO `motorhome`.`person` (`password`, `firstName`, `lastName`, `email`, `siteRole`, `birthDate`, `joinDate`, `Address_idAddress`) VALUES ('password', 'Jeppe', 'Olsen', 'cado@fakemail.com', 'BOOKKEEPER', '19550503', '20200407', '8');

	-- PayCard insert statement:
INSERT INTO `motorhome`.`paycard` (`cardType`, `cardNumber`, `expirationDate`, `securityDigits`) VALUES ('Mastercard', '451223454321234', '20211203', '123');
INSERT INTO `motorhome`.`paycard` (`cardType`, `cardNumber`, `expirationDate`, `securityDigits`) VALUES ('Mastercard', '231320454321234', '20221203', '123');
INSERT INTO `motorhome`.`paycard` (`cardType`, `cardNumber`, `expirationDate`, `securityDigits`) VALUES ('Mastercard', '234543211121234', '20210203', '123');
INSERT INTO `motorhome`.`paycard` (`cardType`, `cardNumber`, `expirationDate`, `securityDigits`) VALUES ('Blastercard', '234513114321234', '20220303', '123');
INSERT INTO `motorhome`.`paycard` (`cardType`, `cardNumber`, `expirationDate`, `securityDigits`) VALUES ('Mastercard', '122323454321234', '20210503', '123');
INSERT INTO `motorhome`.`paycard` (`cardType`, `cardNumber`, `expirationDate`, `securityDigits`) VALUES ('Mastercard', '223343354321234', '20211003', '123');
INSERT INTO `motorhome`.`paycard` (`cardType`, `cardNumber`, `expirationDate`, `securityDigits`) VALUES ('Mastercard', '234543245621234', '20211203', '123');

	-- Customer insert statements
INSERT INTO `motorhome`.`customer` (`driversLicense`, `approved`, `Person_idPerson`, `Paycard_idPaycard`) VALUES ('9999-9999-9999-9999', '1', '1', '7');
INSERT INTO `motorhome`.`customer` (`driversLicense`, `approved`, `Person_idPerson`, `Paycard_idPaycard`) VALUES ('8888-9999-9999-9999', '0', '2', '6');
INSERT INTO `motorhome`.`customer` (`driversLicense`, `approved`, `Person_idPerson`, `Paycard_idPaycard`) VALUES ('7777-9999-9999-9999', '1', '3', '5');
INSERT INTO `motorhome`.`customer` (`driversLicense`, `approved`, `Person_idPerson`, `Paycard_idPaycard`) VALUES ('6666-9999-9999-9999', '0', '4', '4');
INSERT INTO `motorhome`.`customer` (`driversLicense`, `approved`, `Person_idPerson`, `Paycard_idPaycard`) VALUES ('5555-9999-9999-9999', '1', '5', '3');
INSERT INTO `motorhome`.`customer` (`driversLicense`, `approved`, `Person_idPerson`, `Paycard_idPaycard`) VALUES ('4444-9999-9999-9999', '0', '6', '2');
INSERT INTO `motorhome`.`customer` (`driversLicense`, `approved`, `Person_idPerson`, `Paycard_idPaycard`) VALUES ('3333-9999-9999-9999', '1', '7', '1');

	-- Employee insert statements:
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('15', '8');
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('13', '9');
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('1', '10');
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('2', '11');
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('3', '12');
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('4', '13');
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('5', '14');
INSERT INTO `motorhome`.`employee` (`accountancyId`, `Person_idPerson`) VALUES ('6', '15');

	-- Services insert statement
INSERT INTO `motorhome`.`service` (`name`, `description`, `unitPrice`) VALUES ('Wash', 'Extravagant car cleaning', '430');
INSERT INTO `motorhome`.`service` (`name`, `description`, `unitPrice`) VALUES ('Builderdash', 'Something exciting will happen', '230');
INSERT INTO `motorhome`.`service` (`name`, `description`, `unitPrice`) VALUES ('Big Screens', 'Motorhome becomes a ciname', '2700');
INSERT INTO `motorhome`.`service` (`name`, `description`, `unitPrice`) VALUES ('Bike Rack', 'Bike racks are for winners', '2700');
INSERT INTO `motorhome`.`service` (`name`, `description`, `unitPrice`) VALUES ('Child seat', 'We teach your child to go into a seated position', '2700');
INSERT INTO `motorhome`.`service` (`name`, `description`, `unitPrice`) VALUES ('Picnic Table', 'Picnic table for extra dinner space.', '2700');

	-- Carmodel insert statements
INSERT INTO `motorhome`.`carmodel` (`modelName`, `modelNumber`, `horsePower`, `beds`, `engineCapacity`, `length`, `height`, `width`, `weight`, `hotWaterCapacity`, `coldWaterCapacity`, `numberOfSeats`, `oven`, `cruiseControl`, `shower`) VALUES ('Bentova', 'B4-EVA', '230', '2', '420', '5', '4', '2.5', '1800', '80', '100', '6', '1', '1', '1');
INSERT INTO `motorhome`.`carmodel` (`modelName`, `modelNumber`, `horsePower`, `beds`, `engineCapacity`, `length`, `height`, `width`, `weight`, `hotWaterCapacity`, `coldWaterCapacity`, `numberOfSeats`, `oven`, `cruiseControl`, `shower`) VALUES ('Caligula', 'DD42-5', '130', '2', '320', '5', '4', '2.5', '1800', '80', '100', '8', '1', '0', '1');
INSERT INTO `motorhome`.`carmodel` (`modelName`, `modelNumber`, `horsePower`, `beds`, `engineCapacity`, `length`, `height`, `width`, `weight`, `hotWaterCapacity`, `coldWaterCapacity`, `numberOfSeats`, `oven`, `cruiseControl`, `shower`) VALUES ('Tuffnin', 'GF-777', '230', '2', '320', '5', '4', '2.5', '1800', '80', '100', '4', '0', '1', '0');
INSERT INTO `motorhome`.`carmodel` (`modelName`, `modelNumber`, `horsePower`, `beds`, `engineCapacity`, `length`, `height`, `width`, `weight`, `hotWaterCapacity`, `coldWaterCapacity`, `numberOfSeats`, `oven`, `cruiseControl`, `shower`) VALUES ('Swissch', 'A', '230', '2', '350', '5', '4', '2.5', '1800', '80', '100', '5', '1', '0', '1');

	-- Motorhome insert statements
INSERT INTO `motorhome`.`motorhome` (`licensePlate`, `notes`, `imageURL`, `productionYear`, `description`, `minimumDaysOfRental`, `fuelType`, `seasonalDailyCharges`, `carModel_idcarModel`) VALUES ('AH 34 2T2', 'None', '/img/MH1.jpg', '1997', 'Baddies', '5', 'Octane', '520', '1');
INSERT INTO `motorhome`.`motorhome` (`licensePlate`, `notes`, `imageURL`, `productionYear`, `description`, `minimumDaysOfRental`, `fuelType`, `seasonalDailyCharges`, `carModel_idcarModel`) VALUES ('BT 34 2TE', 'None', '/img/MH1.jpg', '1999', 'Baudies', '6', 'Diesel', '520', '2');
INSERT INTO `motorhome`.`motorhome` (`licensePlate`, `notes`, `imageURL`, `productionYear`, `description`, `minimumDaysOfRental`, `fuelType`, `seasonalDailyCharges`, `carModel_idcarModel`) VALUES ('HG 34 2R2', 'None', '/img/MH1.jpg', '1998', 'Buddies', '4', 'Snake-Oil', '520', '3');
INSERT INTO `motorhome`.`motorhome` (`licensePlate`, `notes`, `imageURL`, `productionYear`, `description`, `minimumDaysOfRental`, `fuelType`, `seasonalDailyCharges`, `carModel_idcarModel`) VALUES ('AH DS ET2', 'None', '/img/MH1.jpg', '2012', 'Wingding', '15', 'Octane', '520', '4');
INSERT INTO `motorhome`.`motorhome` (`licensePlate`, `notes`, `imageURL`, `productionYear`, `description`, `minimumDaysOfRental`, `fuelType`, `seasonalDailyCharges`, `carModel_idcarModel`) VALUES ('AH 34 2TW', 'None', '/img/MH1.jpg', '2017', 'Tuskany', '12', 'Octane', '520', '1');
INSERT INTO `motorhome`.`motorhome` (`licensePlate`, `notes`, `imageURL`, `productionYear`, `description`, `minimumDaysOfRental`, `fuelType`, `seasonalDailyCharges`, `carModel_idcarModel`) VALUES ('AD S4 2E2', 'None', '/img/MH1.jpg', '2020', 'Electro', '10', 'Gas', '520', '2');
INSERT INTO `motorhome`.`motorhome` (`licensePlate`, `notes`, `imageURL`, `productionYear`, `description`, `minimumDaysOfRental`, `fuelType`, `seasonalDailyCharges`, `carModel_idcarModel`) VALUES ('XH S2 DT2', 'None', '/img/MH1.jpg', '2015', 'Humphry', '5', 'Octane', '520', '3');

	-- Motorhome_has_Service insert statements
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('1', '1');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('1', '2');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('1', '3');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('2', '4');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('2', '5');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('2', '6');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('3', '1');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('3', '2');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('3', '3');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('4', '4');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('4', '3');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('4', '2');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('5', '1');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('5', '2');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('5', '3');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('6', '4');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('7', '5');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('7', '6');
INSERT INTO `motorhome`.`motorhome_has_service` (`Motorhome_idMotorhome`, `Service_idService`) VALUES ('7', '1');

	-- Period insert statements (for reservations) 
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-05-12', '2021-07-08');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2020-08-12', '2021-10-08');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-07-12', '2021-07-28');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-02-25', '2021-07-08');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-03-25', '2021-07-08');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-04-25', '2021-07-08');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-05-25', '2021-07-08');

	-- Period insert statements (for invoices) 
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-05-12', '2021-06-12');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2020-08-12', '2020-09-12');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-07-12', '2021-08-12');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-02-25', '2021-03-25');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-03-25', '2021-04-25');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-04-25', '2021-05-25');
INSERT INTO `motorhome`.`period` (`start`, `end`) VALUES ('2021-05-25', '2021-08-25');

	-- Reservation insert statements
INSERT INTO `motorhome`.`reservation` (`notes`, `internalNotes`, `reservationStatus`, `Employee_idEmployee`, `Period_idPeriod`, `Motorhome_idMotorhome`, `Customer_driversLicense`) VALUES ('No notes yet.', 'None yet.', 'ACCEPTED', '2', '2', '3', '6666-9999-9999-9999');
INSERT INTO `motorhome`.`reservation` (`notes`, `internalNotes`, `reservationStatus`, `Employee_idEmployee`, `Period_idPeriod`, `Motorhome_idMotorhome`, `Customer_driversLicense`) VALUES ('No notes yet.', 'None yet.', 'ACCEPTED', '2', '3', '3', '5555-9999-9999-9999');
INSERT INTO `motorhome`.`reservation` (`notes`, `internalNotes`, `reservationStatus`, `Employee_idEmployee`, `Period_idPeriod`, `Motorhome_idMotorhome`, `Customer_driversLicense`) VALUES ('No notes yet.', 'None yet.', 'ACCEPTED', '3', '4', '3', '7777-9999-9999-9999');
INSERT INTO `motorhome`.`reservation` (`notes`, `internalNotes`, `reservationStatus`, `Employee_idEmployee`, `Period_idPeriod`, `Motorhome_idMotorhome`, `Customer_driversLicense`) VALUES ('No notes yet.', 'None yet.', 'ACCEPTED', '2', '5', '3', '3333-9999-9999-9999');

	-- Reservation_has_Service statements
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('1', '1');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('2', '1');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '1');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '2');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '3');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '3');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '4');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '4');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '4');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '2');
INSERT INTO `motorhome`.`reservation_has_service` (`Service_idService`, `Reservation_idReservation`) VALUES ('3', '2');


	-- Invoice insert statements
INSERT INTO `motorhome`.`invoice` (`isCompleted`, `billPeriod`, `Motorhome_idMotorhome`, `reservationPeriod`, `Customer_driversLicense`) VALUES ('1', '8', '1', '1', '9999-9999-9999-9999');
INSERT INTO `motorhome`.`invoice` (`isCompleted`, `billPeriod`, `Motorhome_idMotorhome`, `reservationPeriod`, `Customer_driversLicense`) VALUES ('0', '9', '2', '2', '8888-9999-9999-9999');
INSERT INTO `motorhome`.`invoice` (`isCompleted`, `billPeriod`, `Motorhome_idMotorhome`, `reservationPeriod`, `Customer_driversLicense`) VALUES ('1', '10', '3', '3', '7777-9999-9999-9999');
INSERT INTO `motorhome`.`invoice` (`isCompleted`, `billPeriod`, `Motorhome_idMotorhome`, `reservationPeriod`, `Customer_driversLicense`) VALUES ('0', '11', '4', '4', '6666-9999-9999-9999');
INSERT INTO `motorhome`.`invoice` (`isCompleted`, `billPeriod`, `Motorhome_idMotorhome`, `reservationPeriod`, `Customer_driversLicense`) VALUES ('1', '12', '5', '5', '5555-9999-9999-9999');
INSERT INTO `motorhome`.`invoice` (`isCompleted`, `billPeriod`, `Motorhome_idMotorhome`, `reservationPeriod`, `Customer_driversLicense`) VALUES ('0', '13', '6', '6', '4444-9999-9999-9999');
INSERT INTO `motorhome`.`invoice` (`isCompleted`, `billPeriod`, `Motorhome_idMotorhome`, `reservationPeriod`, `Customer_driversLicense`) VALUES ('1', '14', '7', '7', '3333-9999-9999-9999');



	-- Appointment insert statements
INSERT INTO `motorhome`.`appointment` (`date`, `time`, `notes`, `distance`, `Address_idAddress`, `Motorhome_idMotorhome`) VALUES ('2021-05-12', '12:00:00', 'Drop off', '30', '1', '1');
INSERT INTO `motorhome`.`appointment` (`date`, `time`, `notes`, `distance`, `Address_idAddress`, `Motorhome_idMotorhome`) VALUES ('2020-08-12', '17:00:00', 'Drop off', '50', '2', '2');
INSERT INTO `motorhome`.`appointment` (`date`, `time`, `notes`, `distance`, `Address_idAddress`, `Motorhome_idMotorhome`) VALUES ('2021-07-28', '20:00:00', 'Pick up', '100', '1', '1');
INSERT INTO `motorhome`.`appointment` (`date`, `time`, `notes`, `distance`, `Address_idAddress`, `Motorhome_idMotorhome`) VALUES ('2021-02-25', '18:00:00', 'Pick up', '41', '3', '3');

	-- Employee_has_Appointment statements
INSERT INTO `motorhome`.`employee_has_appointment` (`Employee_idEmployee`, `Appointment_idAppointment`) VALUES ('1', '1');
INSERT INTO `motorhome`.`employee_has_appointment` (`Employee_idEmployee`, `Appointment_idAppointment`) VALUES ('1', '2');
INSERT INTO `motorhome`.`employee_has_appointment` (`Employee_idEmployee`, `Appointment_idAppointment`) VALUES ('1', '3');
INSERT INTO `motorhome`.`employee_has_appointment` (`Employee_idEmployee`, `Appointment_idAppointment`) VALUES ('2', '4');

	-- Invoice_has_Service statements
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('1', '1');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('1', '2');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('1', '3');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('2', '2');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('2', '4');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('3', '1');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('3', '2');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('4', '3');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('4', '2');
INSERT INTO `motorhome`.`invoice_has_service` (`Invoice_idInvoice`, `Service_idService`) VALUES ('4', '4');

	-- Reservation_has_Appointment statements
INSERT INTO `motorhome`.`reservation_has_appointment` (`Reservation_idReservation`, `Appointment_idAppointment`) VALUES ('1', '1');
INSERT INTO `motorhome`.`reservation_has_appointment` (`Reservation_idReservation`, `Appointment_idAppointment`) VALUES ('2', '2');
INSERT INTO `motorhome`.`reservation_has_appointment` (`Reservation_idReservation`, `Appointment_idAppointment`) VALUES ('3', '3');
INSERT INTO `motorhome`.`reservation_has_appointment` (`Reservation_idReservation`, `Appointment_idAppointment`) VALUES ('4', '4');